import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class BrowserCaller {
	
	public void OpenBroswerFireFox(){
		
		//Open Firefox Browser
		WebDriver driver = new FirefoxDriver();
		driver.navigate().to("http://www.google.com");
	
	}
	
	
	public void OpenBrowserIE(){
		// IE

		// The following snippet of WebDriver Java code should work to launch IE.
		// The code will ignore the setup of Protected mode settings for all zones in the IE browser.
		// Check out: http://stackoverflow.com/questions/14952348/not-able-to-launch-ie-browser-using-selenium2-webdriver-with-java

		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		
		// capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING,true);
		
		System.setProperty("webdriver.ie.driver", "C:\\Selenium\\IEDriverServer_Win32\\IEDriverServer.exe");
		
		WebDriver driver = new InternetExplorerDriver(capabilities);
		
		//driver.navigate().to("http://www.google.com");
		driver.get("http://www.google.com");
		
		try {
			Thread.sleep(5000);
			System.out.println("User successfully navigated to Internet Explorer Browser.");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	public void OpenBrowserChrome(){
		
		//Open Chrome Browser
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.navigate().to("http://www.google.com");
		try {
			Thread.sleep(5000);
			System.out.println("User successfully navigated to Chrome Browser.");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		driver.close();
		
	}
	
}
