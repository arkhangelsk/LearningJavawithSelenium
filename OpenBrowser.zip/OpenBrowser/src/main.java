
public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BrowserCaller bc = new BrowserCaller();
		bc.OpenBrowserChrome();
	//	bc.OpenBrowserIE();
	}

}
