
public class GetSetupData {

}
