import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class GetTestData {

	private static final String FILE_PATH = "C:\\Development\\Selenium\\Framework\\GetExternalData\\TestData\\MasterTestData.xlsx";
	String sRunFlag = "";
	String sEnvironmentToRun = "";
	String sBrowserToRun = "";
	String sTC_ID = "";

	public void getTestFileData() {

		FileInputStream fis = null;
		
		HashMap<Integer, String> hmap = new HashMap<Integer, String>();

		try {
			fis = new FileInputStream(FILE_PATH);

			// Using XSSF for xlsx format, for xls use HSSF
			Workbook workbook = new XSSFWorkbook(fis);

			int numberOfSheets = workbook.getNumberOfSheets();

			System.out.println("No. Of sheets in workbook: " + numberOfSheets);

			// looping over each workbook sheet
			for (int i = 0; i < numberOfSheets; i++) {
				Sheet sheet = workbook.getSheetAt(i);
				
				Iterator<Row> rowIterator = sheet.iterator();

				if (sheet.getSheetName().equalsIgnoreCase("TestScenarioInfo")) {
					
					System.out.println("Sheet Name: " + sheet.getSheetName());
					
					System.out.println("Total Number of Rows in the Sheet: " + sheet.getPhysicalNumberOfRows());
					
					// iterating over each row
					while (rowIterator.hasNext()) {
						
						Row row = rowIterator.next();
						Iterator<Cell> cellIterator = row.cellIterator();

						// Iterating over each cell (column wise) in a
						// particular row.
						while (cellIterator.hasNext()) {

							Cell cell = cellIterator.next();
							
						
							
							for (int j=1; j<=sheet.getPhysicalNumberOfRows(); j++ ){
								
							// Getting data for TC_ID
							if (cell.getRowIndex() == j && cell.getColumnIndex() == 0) {

								sTC_ID = cell.getStringCellValue();
								
								System.out.println("TC_ID: " + sTC_ID);
								
							}
								
							
							// Getting data for Run Flag
								if (cell.getRowIndex() == j && cell.getColumnIndex() == 2) {

									sRunFlag = cell.getStringCellValue();
									System.out.println("Run Flag: " + sRunFlag);
									
									if(sRunFlag.equalsIgnoreCase("Y")){
										hmap.put(j, sTC_ID);
									}
									
									
									
								}

								// Getting data for EnvironmentToRun
								if (cell.getRowIndex() == j && cell.getColumnIndex() == 3) {

									sEnvironmentToRun = cell.getStringCellValue();
									System.out.println("Environment to Run: " + sEnvironmentToRun);
								}

								// Getting data for BrowserToRun
								if (cell.getRowIndex() == j && cell.getColumnIndex() == 4) {
									sBrowserToRun = cell.getStringCellValue();
									System.out.println("Browser to Run: " + sBrowserToRun);
								}

								
								
							}
							
						
						}// end iterating a row, add all the elements of a row in list

						
					}
					
					/* Display content using Iterator*/
				      Set set = hmap.entrySet();
				      Iterator iterator = set.iterator();
				      while(iterator.hasNext()) {
				         Map.Entry mentry = (Map.Entry)iterator.next();
				         System.out.print("key is: "+ mentry.getKey() + " & Value is: ");
				         System.out.println(mentry.getValue());
				      }
				}
			}

			fis.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
