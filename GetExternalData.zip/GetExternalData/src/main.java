
public class main {

	public static void main(String[] args) {
		
		GetSetupData getSetupData 		= new GetSetupData();
		GetTestData getTestData 		= new GetTestData();
		BrowserCaller browsertoRun		= new BrowserCaller();				
		
		
	//	System.out.println("Getting data from Setup File........................................");
		
	//	getSetupData.getSetupFileData();
		
		System.out.println("Getting data from Master Test Data File........................................");

		getTestData.getTestFileData();
		
		String sTCID = getTestData.sTC_ID;
		String sEnvironment	= getTestData.sEnvironmentToRun;
		String sBrowsertoRun = getTestData.sBrowserToRun;
		
		System.out.println("Test Case ID:" + sTCID);
		System.out.println("Environment To Run:" + sEnvironment);
		System.out.println("Browser:" + sBrowsertoRun);
		
		
	//	browsertoRun.openBrowser(sBrowsertoRun);
		
		
		
	}

}
